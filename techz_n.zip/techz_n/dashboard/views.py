from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from authentication import views as aviews

def index(request):
    return render(request,"dashboard.html")

def career(request):
    return render(request,"career_cons.html")

def job(request):
    return render(request,"job_cons.html")

def educational(request):
    return render(request,"edu_cons.html")


def booking(request):
    return render(request,"booking.html")
