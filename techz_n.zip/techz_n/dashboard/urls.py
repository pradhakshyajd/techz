from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.index, name="home"),
    path('career/',views.career,name="career"),
    path('job/',views.job,name="job"),
    path('educational/',views.educational,name="ed"),
    path('booking/',views.booking,name="book"),

]