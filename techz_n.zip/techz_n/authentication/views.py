from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.forms.utils import ErrorList
from django.http import HttpResponse
from .forms import LoginForm,SignUpForm
# Create your views here.

def login(request):
    return render(request,"accounts/login.html")

def register(request):
    return render(request,"accounts/registration.html")


def login_view(request):
    form = LoginForm(request.POST or None)

    msg = None

    if request.method == "POST":

        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                return redirect("/dashboard/home")
            else:    
                msg = 'Invalid credentials'    
        else:
            msg = 'Error validating the form'    

    return render(request, "accounts/login.html", {"form": form, "msg" : msg})


def register_user(request):
    msg     = None
    success = False

    if request.method == "POST":
        form = SignUpForm(request.POST)
        print(form)
        if form.is_valid():
            print("Form is valid")
            form.save()
            #firstname = form.cleaned_data.get("firstname")
            #lastname = form.cleaned_data.get("lastname")
            #email = form.cleaned_data.get("email")
            #phoneno = form.cleaned_data.get("phoneno")
            #country = form.cleaned_data.get("country")
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            con_password = form.cleaned_data.get("password2")

            if raw_password != con_password:
                raise forms.ValidationError(
                    "password and confirm_password does not match"
                )

            user = authenticate(username=username, password=raw_password)

            msg     = 'User created.'
            success = True
            

        else:
        
            msg = 'Form is not valid'    
    else:
        form = SignUpForm()
    return render(request, "accounts/register.html", {"form": form, "msg" : msg, "success" : success })


def login_view1(request):
    form = LoginForm(request.POST or None)

    msg = None

    if request.method == "POST":

        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                return redirect("/dashboard/booking")
            else:    
                msg = 'Invalid credentials'    
        else:
            msg = 'Error validating the form'    

    return render(request, "accounts/login.html", {"form": form, "msg" : msg})